# Usage with Playscii

https://jplebreton.com/playscii/

To use this font with Playscii, copy the .char and .png files under charsets/
to the charsets/ directory within your Playscii installation. Optionally, copy
the palette file under palettes/ as well.

To check if everything is set up correctly, load the example image (.psci)
under art/ and compare it to the .png export in the same folder.

For more information, see the Playscii documentation on custom character sets:
https://jplebreton.com/playscii/howto_art.html#customcharsets
